
class Animal {
  final String id;
  final String name;
  final String type;
  final String icon_url;

  const Animal({
    required this.id,
    required this.name,
    required this.type,
    required this.icon_url,
  });
}